#!/usr/bin/env python3
"""Static CP-0009D safety: a packaged offline shell cannot quietly acquire RF privileges."""
from __future__ import annotations
import pathlib
import re
import xml.etree.ElementTree as ET

root = pathlib.Path(__file__).resolve().parents[1]
manifest = root / "app/src/main/AndroidManifest.xml"
source = root / "app/src/main/java/dev/n0png/fieldops/app/MainActivity.java"
appgradle = root / "app/build.gradle.kts"
app = ET.parse(manifest).getroot()
android = "{http://schemas.android.com/apk/res/android}"
if app.findall("uses-permission"):
    raise SystemExit("CP-0009D shell must declare NO runtime permissions")
if app.findall("uses-feature"):
    raise SystemExit("CP-0009D shell must not depend on radio hardware")
activities = app.findall("application/activity")
activity = next((a for a in activities if a.get(android + "name") ==
                 "dev.n0png.fieldops.app.MainActivity"), None)
archive = next((a for a in activities if a.get(android + "name") ==
                "dev.n0png.fieldops.app.ArchiveHistoryActivity"), None)
if archive is None or archive.get(android + "exported") != "false":
    raise SystemExit("Synthetic archive must be private to the app")
if activity is None or activity.get(android + "exported") != "true":
    raise SystemExit("Missing explicit launcher Activity export")
if not any(a.get(android + "name") == "android.intent.action.MAIN"
           for a in activity.findall("intent-filter/action")):
    raise SystemExit("Missing Android MAIN launcher intent")
text = source.read_text()
for token in ("startService(", "sendBroadcast(", "UsbManager", "AudioRecord(",
              "requestPermissions(", "getSystemService(", "HttpURLConnection",
              "DatagramSocket", "android.permission"):
    if token in text:
        raise SystemExit("Unexpected integration beyond offline packaging: " + token)
if "does not connect to a radio" not in text:
    raise SystemExit("Missing explicit no-radio developer UI notice")
gradle = appgradle.read_text()
for field in ("applicationId = \"dev.n0png.fieldops\"", "compileSdk = 35",
              "targetSdk = 35", "versionCode = 57"):
    if field not in gradle:
        raise SystemExit("Android packaging contract missing: " + field)
print("CP-0009D offline application shell/manifest safety contract: PASS")

archive_src = root / "app/src/main/kotlin/dev/n0png/fieldops/app/ArchiveHistoryActivity.kt"
if not archive_src.is_file():
    raise SystemExit("Missing CP-0009E Android archive Activity")
source_text = archive_src.read_text()
for required in ("PropagationArchiveWorkspaceService", "PropagationArchiveWorkspaceAction.Select(",
                 "PropagationArchiveWorkspaceAction.Compare(", "PropagationArchiveWorkspaceAction.Delete(",
                 "PropagationArchiveWorkspaceAction.NextPage", "PropagationArchiveWorkspaceAction.PreviousPage",
                 "screen.provenanceNotices", "InMemoryPropagationSnapshotStore",
                 "NOT LIVE", "contentDescription"):
    if required not in source_text:
        raise SystemExit("Archive UI must use canonical model with history warning: " + required)
for disallowed in ("UsbManager", "AudioRecord", "startService(", "requestPermissions(",
                   "HttpURLConnection", "DatagramSocket", "FileOutputStream"):
    if disallowed in source_text:
        raise SystemExit("CP-0009E history demonstration requests real hardware I/O: " + disallowed)
print("CP-0009E Android synthetic archive navigation contract: PASS")

# CP-0009F: only nonconfiguration in-memory state may be retained.
archive_kotlin = archive_src.read_text()
for required in ("onRetainNonConfigurationInstance()", "lastNonConfigurationInstance", "RotationSession", "Fresh process/session"):
    if required not in archive_kotlin:
        raise SystemExit("Missing transient-only archive lifecycle contract: " + required)
for forbidden in ("openFileOutput(", "getSharedPreferences(", "Room.databaseBuilder", "FileOutputStream", "SavedStateHandle"):
    if forbidden in archive_kotlin:
        raise SystemExit("Unexpected durable Android archive storage: " + forbidden)
print("CP-0009F transient rotation/session storage boundary: PASS")
